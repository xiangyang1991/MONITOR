#!/bin/bash
. ./set_color
echo -e "${red_1} hello$end"
echo -e "$green_1 hello $end"
echo -e "$yellow_1 hello $end"
